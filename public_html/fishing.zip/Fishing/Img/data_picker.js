$(document).ready(function()
 {
   
    $("#dtBox").DateTimePicker({
        dateFormat: "dd-MM-yyyy",
    });
    $("#dtBox1").DateTimePicker();
 });